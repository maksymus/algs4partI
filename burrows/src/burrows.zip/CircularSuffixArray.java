import java.util.Arrays;
import java.util.Random;

public class CircularSuffixArray {
    private class Suffix implements Comparable<Suffix> {
        private int idx;

        public Suffix(int idx) {
            this.idx = idx;
        }

        private char charAt(int i) {
            return string.charAt((i + idx) % string.length());
        }

        private boolean less(Suffix other, int d) {
            for (int i = d; i < string.length(); i++) {
                int c1 = this.charAt(i);
                int c2 = other.charAt(i);
                if (c1 < c2) {
                    return true;
                } else if (c2 < c1) {
                    return false;
                }
            }
            return false;
        }

        @Override
        public int compareTo(Suffix suffix) {
            for (int i = 0; i < string.length(); i++) {
                char thisChar = this.charAt(i);
                char otherChar = suffix.charAt(i);

                int compare = Character.compare(thisChar, otherChar);
                if (compare != 0)
                    return compare;
            }

            return 0;
        }
    }

    private static class Quick3Suffixes {
        private static final int CUTOFF =  15;   // cutoff to insertion sort

        // sort the array indices[] of suffix indices for string
        public static void sort(String a, int[] inds) {
            sort(a, inds, 0, inds.length-1, 0);
        }

        // return the dth character of suffix starting at s[sufIdx],
        // -1 if d = length of s
        private static int charAt(String s, int sufIdx, int d) {
            assert d >= 0 && d <= s.length();
            int idx = sufIdx + d;
            if (idx >= s.length()) {
                idx = idx - s.length();
            }
            if (d == s.length()) return -1;
            return s.charAt(idx);
        }


        // 3-way string quicksort inds[lo..hi] starting at dth character
        private static void sort(String a, int[] inds, int lo, int hi, int d) {
            // cutoff to insertion sort for small subarrays
            if (hi <= lo + CUTOFF) {
                insertion(a, inds, lo, hi, d);
                return;
            }

            int lt = lo, gt = hi;
            int v = charAt(a, inds[lo], d);
            int i = lo + 1;
            while (i <= gt) {
                int t = charAt(a, inds[i], d);
                if      (t < v) exch(inds, lt++, i++);
                else if (t > v) exch(inds, i, gt--);
                else              i++;
            }

            // a[lo..lt-1] < v = a[lt..gt] < a[gt+1..hi].
            sort(a, inds, lo, lt-1, d);
            if (v >= 0) sort(a, inds, lt, gt, d+1);
            sort(a, inds, gt+1, hi, d);
        }



        // sort from a[lo] to a[hi], starting at the dth character
        private static void insertion(String a, int[] inds, int lo, int hi, int d) {
            for (int i = lo; i <= hi; i++)
                for (int j = i; j > lo && less(a, inds[j], inds[j-1], d); j--)
                    exch(inds, j, j-1);
        }

        // exchange a[i] and a[j]
        private static void exch(int[] a, int i, int j) {
            int temp = a[i];
            a[i] = a[j];
            a[j] = temp;
        }

        // compare two suffixes, starting at character d
        private static boolean less(String a, int sufInd1, int sufInd2, int d) {
            for (int i = d; i < a.length(); i++) {
                int c1 = charAt(a, sufInd1, i);
                int c2 = charAt(a, sufInd2, i);
                if (c1 < c2) {
                    return true;
                } else if (c2 < c1) {
                    return false;
                }
            }
            return false;
        }
    }

    private String string;
//    private Suffix[] refs;
    private int[] indices;

    // circular suffix array of s
    public CircularSuffixArray(String s) {
        if (s == null)
            throw new NullPointerException();

        this.string = s;
//        this.refs = new Suffix[s.length()];
//
//        for (int i = 0; i < s.length(); i++)
//            refs[i] = new Suffix(i);
//
//        sort(refs);

        indices = new int[s.length()];
        // Construct original array
        for (int i = 0; i < indices.length; i++) {
            indices[i] = i;
        }
        // Sort suffixes
        Quick3Suffixes.sort(s, indices);
    }

    // length of s
    public int length() {
        return string.length();
    }

    // returns index of ith sorted suffix
    public int index(int i) {
        if (i < 0 || i > string.length())
            throw new IndexOutOfBoundsException();

//        return refs[i].idx;
        return indices[i];
    }

    private void sort(Suffix[] suffixes) {
//        new Quick3Suffixes().sort(suffixes);
        Arrays.sort(suffixes);
    }

    // unit testing of the methods (optional)
    public static void main(String[] args) {
        String str = "";
        Random rnd = new Random();
        for (int i = 0; i < 10000; i++) {
            str += i;
        }

        System.out.println(new CircularSuffixArray(str).index(0));
        System.out.println();

        int[] ints = {11, 10, 7, 0, 3, 5, 8, 1, 4, 6, 9, 2};
        for (int i = 0; i < 12; i++) {
            int res = new CircularSuffixArray("ABRACADABRA!").index(i);
            System.out.print(res + " ");
            if (res != ints[i])
                System.out.printf("Wrong number at pos %d [expected: %d observed: %d]\n", i, ints[i], res);
        }
    }
}